package com.example.lumiapp;

public interface AuthFragmentSwitcher {
    void switchToLogin();
    void switchToSignup();
}
